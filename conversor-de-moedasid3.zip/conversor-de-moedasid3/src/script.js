function Converter_dolar() {
  var valorElemento = document.getElementById("dolar");
  var dolar = valorElemento.value;
  var valorEmDolarNumerico = parseFloat(dolar);
  console.log(valorEmDolarNumerico);

  var valorEmReal = valorEmDolarNumerico * 5;
  console.log(valorEmReal);

  var elementoValorCovertidoDolar = document.getElementById(
    "valorConvertidoDolar"
  );
  var valorConvertidoDolar = "O Resultado em R$ " + valorEmReal;
  elementoValorCovertidoDolar.innerHTML = valorConvertidoDolar;
}
function Converter_euro() {
  var valorElemento = document.getElementById("euro");
  var euro = valorElemento.value;
  var valorEmEuroNumerico = parseFloat(euro);
  console.log(valorEmEuroNumerico);

  var valorEmReal = valorEmEuroNumerico * 6.28;
  console.log(valorEmReal);

  var elementoValorConvertidoEuro = document.getElementById(
    "valorConvertidoEuro"
  );
  var valorConvertidoEuro = "O Resultado em R$ " + valorEmReal;
  elementoValorConvertidoEuro.innerHTML = valorConvertidoEuro;
}
